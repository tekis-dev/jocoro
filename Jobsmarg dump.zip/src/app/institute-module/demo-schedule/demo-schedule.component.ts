import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-schedule',
  templateUrl: './demo-schedule.component.html',
  styleUrls: ['./demo-schedule.component.css']
})
export class DemoScheduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
