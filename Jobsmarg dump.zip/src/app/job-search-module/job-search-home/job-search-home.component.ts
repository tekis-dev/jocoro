import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-search-home',
  templateUrl: './job-search-home.component.html',
  styleUrls: ['./job-search-home.component.css']
})
export class JobSearchHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
