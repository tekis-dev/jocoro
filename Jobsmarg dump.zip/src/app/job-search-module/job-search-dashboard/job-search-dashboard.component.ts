import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-search-dashboard',
  templateUrl: './job-search-dashboard.component.html',
  styleUrls: ['./job-search-dashboard.component.css']
})
export class JobSearchDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
