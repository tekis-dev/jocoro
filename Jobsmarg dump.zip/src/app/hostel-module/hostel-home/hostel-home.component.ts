import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hostel-home',
  templateUrl: './hostel-home.component.html',
  styleUrls: ['./hostel-home.component.css']
})
export class HostelHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
