import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hostel-dashboard',
  templateUrl: './hostel-dashboard.component.html',
  styleUrls: ['./hostel-dashboard.component.css']
})
export class HostelDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
