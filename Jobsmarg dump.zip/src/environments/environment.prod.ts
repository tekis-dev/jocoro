export const environment = {
  production: true,
  apiUrl:  'http://122.175.58.27:3000', // 'http://localhost:3000', //
};
